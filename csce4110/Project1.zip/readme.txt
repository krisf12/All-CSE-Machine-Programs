STEPS:

1.) Compile and execute the create_graph.cpp. This creates a file called graph which will be used for the two algorithms.

2.) Compile and execute the c++ program titled floyd.cpp

3.) Compile and execute the c++ program titled dijkstra.cpp

Both of the programs output their runtimes into the command line and output the shortest path matrices into two separate files.
